<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['error_prefix'] = '<small class="md-help-block text-danger">';
$config['error_suffix'] = '</small>';