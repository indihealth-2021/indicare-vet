<?php
/**
 * Created by PhpStorm.
 * User: agungrizkyana
 * Date: 7/16/17
 * Time: 17:14
 */

$config['socket'] = [
    'host' => 'https://telemedicinelintas.indihealth.com',
    'port' => '7000'
];
